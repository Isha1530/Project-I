document.addEventListener('DOMContentLoaded', function () {
    const pricePerPound = 2.50; // Price per pound for apples
    const weightSelect = document.getElementById('weightSelect');
    const totalPriceElement = document.getElementById('totalPrice');

    // Function to update price based on selected weight
    function updatePrice() {
        const selectedWeight = parseFloat(weightSelect.value);
        const totalPrice = (selectedWeight * pricePerPound).toFixed(2);
        totalPriceElement.textContent = totalPrice;
    }

    // Listen for changes on the weight dropdown
    weightSelect.addEventListener('change', updatePrice);
});
